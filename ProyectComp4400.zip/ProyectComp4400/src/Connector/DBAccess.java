/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connector;

import Model.Customer;
import Model.Movies;
import Model.Rent;
import java.sql.*; 
import  java.sql.Driver;
import java.util.*; 
import javax.swing.JOptionPane;
import proyectcomp4400.Log_in;
import proyectcomp4400.NewDataBase;


/**
 *
 * @author crist
 */
 


public class DBAccess {
     static  Connection comm = null;
       static String Port = "3306";
       static String URL = "Jdbc:mysql://localhost:"+Port+"/";
       static String Url = "Jdbc:mysql://localhost:3306/";
       static String driver = "com.mysql.jdbc.Driver"; 
       static String dbName = "pf";
       static String UserName = "root";
       static String Password = "root"; 
       static String SSL = "?autoReconnect=true&useSSL=false";

    public static String getPort() {
        return Port;
    }

    public static void setPort(String Port) {
        DBAccess.Port = Port;
    }

    public static String getUserName() {
        return UserName;
    }

    public static void setUserName(String UserName) {
        DBAccess.UserName = UserName;
    }

    public static String getPassword() {
        return Password;
    }

    public static void setPassword(String Password) {
        DBAccess.Password = Password;
    }
       public static Connection DBAccess(){
             try{
         Class.forName(driver).newInstance(); 
         new NewDataBase().setVisible(true);
         
         
         new Log_in().setVisible(false);
         
         
         comm = DriverManager.getConnection(URL+dbName+SSL, getUserName(), getPassword());
             }catch(Exception e){
               new Log_in().setVisible(false);
               new NewDataBase().setVisible(true);
                try {
        String url = "jdbc:mysql://localhost:3306";
        
        String Creater = 
        		"CREATE DATABASE IF NOT EXISTS `pf` DEFAULT CHARACTER SET utf8 ;\r\n" 
        		;
        
        String CreaterTabelCustomer =
        		"CREATE TABLE IF NOT EXISTS `pf`.`customer` (\r\n" + 
        		"  `idCustomer` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,\r\n" + 
        		"  `FirstName` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `LastName` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `MiddleName` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `Address` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `City` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `ZipCode` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `Phone` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `Admin` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `UserName` VARCHAR(45) NOT NULL,\r\n" + 
        		"  `Password` VARCHAR(45) NOT NULL,\r\n" + 
        		"  `DOB` VARCHAR(45) NULL DEFAULT NULL);\r\n" ;
        String CreaterTabelMovie =
        		
        		"CREATE TABLE IF NOT EXISTS `pf`.`movies` (\r\n" + 
        		"  `idMovies` INT(11) NOT NULL AUTO_INCREMENT,\r\n" + 
        		"  `Title` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `ReleaseDate` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `Genre` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `RunTime` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  `Rated` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  PRIMARY KEY (`idMovies`));\r\n" 
        		 ;
        String CreaterTabelRent =	
        		"CREATE TABLE IF NOT EXISTS `pf`.`rent` (\r\n" + 
        		"  `CusId` INT(11) NOT NULL,\r\n" + 
        		"  `MovieId` INT(11) NOT NULL,\r\n" + 
        		"  `RentDate` VARCHAR(45) NULL DEFAULT NULL,\r\n" + 
        		"  PRIMARY KEY (`CusId`, `MovieId`),\r\n" + 
        		"  INDEX `fk_Customer_has_Movies_Movies1_idx` (`MovieId` ASC),\r\n" + 
        		"  INDEX `fk_Customer_has_Movies_Customer_idx` (`CusId` ASC),\r\n" + 
        		"  INDEX `idCus` (`CusId` ASC),\r\n" + 
        		"  CONSTRAINT `fk_Customer_has_Movies_Customer`\r\n" + 
        		"    FOREIGN KEY (`CusId`)\r\n" + 
        		"    REFERENCES `pf`.`customer` (`idCustomer`)\r\n" + 
        		"    ON DELETE NO ACTION\r\n" + 
        		"    ON UPDATE NO ACTION,\r\n" + 
        		"  CONSTRAINT `fk_Customer_has_Movies_Movies1`\r\n" + 
        		"    FOREIGN KEY (`MovieId`)\r\n" + 
        		"    REFERENCES `pf`.`movies` (`idMovies`)\r\n" + 
        		"    ON DELETE NO ACTION\r\n" + 
        		"    ON UPDATE NO ACTION);\r\n" + 
        		 
        		""
;
        String Admin =  "INSERT INTO `pf`.`customer` (`UserName`, `Password`, `Admin`) VALUES ('Admin', 'Admin', 'Yes');";
        String DataBaseSetUp = "CREATE TABLE IF NOT EXISTS `pf`.`databaselogin` (\n" +
                                "  `Port` VARCHAR(250) NULL DEFAULT NULL,\n" +
                                "  `UserName` VARCHAR(250) NULL DEFAULT NULL,\n" +
                                "  `password` VARCHAR(250) NULL DEFAULT NULL)\n" +
                                "ENGINE = InnoDB\n" +
                                "DEFAULT CHARACTER SET = utf8;";
        String InsertSetUpPermenent = "INSERT INTO `pf`.`databaselogin` (`UserName`, `password`, `port`) VALUES ('"+getUserName()+"', '"+getPassword()+"', '"+getPort()+"');";
        comm = DriverManager.getConnection(url,UserName, Password);
        Statement statement = comm.createStatement();
        statement.executeUpdate(Creater);
        comm = DriverManager.getConnection(Url+dbName+SSL,UserName ,Password);
        statement.executeUpdate(CreaterTabelCustomer);
        statement.executeUpdate(CreaterTabelMovie);
        statement.executeUpdate(CreaterTabelRent);
        statement.executeUpdate(Admin);
        statement.executeUpdate(DataBaseSetUp);
        statement.executeUpdate(InsertSetUpPermenent);
        
        JOptionPane.showMessageDialog(null, dbName + " Database has been created successfully", "System Message", JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception i) {
        JOptionPane.showMessageDialog(null, "Error DataBase not found: \nFollow this instructions to fix this data base \n 1. check the Speelling of your user name \n 2. Check if the password is the correcto one \n 3. check if that your mysql port is the correct one (note this aplication only uses port 3306 when setting up you data base remeber to make the port 3306) \n 4. if all of them fail please install mysql server, you can find it in this link: \n https://dev.mysql.com/downloads/installer/", "System Message", JOptionPane.INFORMATION_MESSAGE);
        }      
             }
             return(comm);
       }
        public static void Exit (){
         try{
          comm.close();
         }catch(Exception e){
             e.printStackTrace();
         }
     }
 
}
