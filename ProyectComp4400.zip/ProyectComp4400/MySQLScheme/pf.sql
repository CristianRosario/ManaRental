-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema pf
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema pf
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `pf` DEFAULT CHARACTER SET utf8 ;
USE `pf` ;

-- -----------------------------------------------------
-- Table `pf`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pf`.`customer` (
  `idCustomer` INT(11) NOT NULL AUTO_INCREMENT,
  `FirstName` VARCHAR(45) NULL DEFAULT NULL,
  `LastName` VARCHAR(45) NULL DEFAULT NULL,
  `MiddleName` VARCHAR(45) NULL DEFAULT NULL,
  `Address` VARCHAR(45) NULL DEFAULT NULL,
  `City` VARCHAR(45) NULL DEFAULT NULL,
  `ZipCode` VARCHAR(45) NULL DEFAULT NULL,
  `Phone` VARCHAR(45) NULL DEFAULT NULL,
  `Admin` VARCHAR(45) NULL DEFAULT NULL,
  `UserName` VARCHAR(45) NOT NULL,
  `Password` VARCHAR(45) NOT NULL,
  `DOB` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idCustomer`),
  UNIQUE INDEX `UserName_UNIQUE` (`UserName` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 13
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `pf`.`movies`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pf`.`movies` (
  `idMovies` INT(11) NOT NULL AUTO_INCREMENT,
  `Title` VARCHAR(45) NULL DEFAULT NULL,
  `ReleaseDate` VARCHAR(45) NULL DEFAULT NULL,
  `Genre` VARCHAR(45) NULL DEFAULT NULL,
  `RunTime` VARCHAR(45) NULL DEFAULT NULL,
  `Rated` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idMovies`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `pf`.`rent`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pf`.`rent` (
  `CusId` INT(11) NOT NULL,
  `MovieId` INT(11) NOT NULL,
  `RentDate` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`CusId`, `MovieId`),
  INDEX `fk_Customer_has_Movies_Movies1_idx` (`MovieId` ASC),
  INDEX `fk_Customer_has_Movies_Customer_idx` (`CusId` ASC),
  INDEX `idCus` (`CusId` ASC),
  CONSTRAINT `fk_Customer_has_Movies_Customer`
    FOREIGN KEY (`CusId`)
    REFERENCES `pf`.`customer` (`idCustomer`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Customer_has_Movies_Movies1`
    FOREIGN KEY (`MovieId`)
    REFERENCES `pf`.`movies` (`idMovies`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
